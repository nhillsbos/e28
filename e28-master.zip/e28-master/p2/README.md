# Project 2
+ By: Madusha Gamage
+ Production URL: <http://p2.yourdegreestuff.com>

## Build strategy
+ [ ] Integrated
+ [X] Comprehensive

## Outside resources
Logo file : https://secure.i.telegraph.co.uk/multimedia/archive/03015/RockPaperScissors_3015010b.jpg

## Notes for instructor
